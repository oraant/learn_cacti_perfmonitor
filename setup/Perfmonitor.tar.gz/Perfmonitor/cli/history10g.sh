#!/bin/bash
#vi history.sh

#user define
hostid=$2 #指定主机的ID
treeid=2 #指定绘图的tree
nodename="Oracle10g历史数据分析平台-节点$1" #不允许空格出现！！！指定要添加的节点的名称
gtid=37 #指定绘图模板的路径
path_user=oracle10g #指定从哪个路径下寻找rrd
path_node=node$1 #指定从哪个节点路径下寻找rrd


#predefine
php=php
glogfile="./log_graph_$hostid.log"
tlogfile="./log_tree_$hostid.log"
rm $glogfile
rm $tlogfile
database="cmn"
graphs=156

#---------------------------------------------
#graph for history host
echo "graph for history host start"
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='数据库实际工作时间(DB time) <分钟/小时>' --force >$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='用户连接数(logons current)' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='事务回滚数量(user rollbacks) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='事务回滚数量(transaction rollbacks) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='事务请求数(user calls) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='事务提交数(user commits) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='脏块产生量(db block changes) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL执行数量(execute count) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='解析总体花费时间(parse time elapsed) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='解析花费CPU时间(parse time cpu) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='硬解析数量(parse count (hard)) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='解析失败次数(parse count (failures)) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='数据库用户进程CPU时间(CPU used by this session) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='select内存读(consistent gets) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='数据库用户进程内存总读取量(session logical reads) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='内存读冲突(数据块装载期间)(read by other session) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='dml内存读(db block gets) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='物理读总请求数量(physical read total IO requests) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='物理读(physical reads) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='直接物理读(physical reads direct) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='多块物理读请求次数(physical read total multi block requests) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='全表扫描物理读次数(db file scattered read) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='临时表空间直接物理读(physical reads direct temporary tablespace) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='物理读吞吐量(physical read total bytes) <MB/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='索引访问物理读(db file sequential read) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='并行物理读(db file parallel read) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='索引快速全扫描I/O(index fast full scans (full)) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='物理写(physical writes) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='直接物理写(physical writes direct) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='物理写吞吐量(physical write total bytes) <MB/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='物理写总请求(physical write total IO requests) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='临时表空间直接物理写(physical writes direct temporary tablespace) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='缓冲区至磁盘物理写(physical writes from cache) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='多块物理写请求次数(physical write total multi block requests) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='lob对象直接物理写(physical writes direct (lob)) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='lob对象物理写(lob writes) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='临时表空间直接路径物理读(direct path read temp) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='归档日志I/O(Log archive I/O) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='临时表空间直接路径物理写(direct path write temp) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='数据泵物理I/O(Datapump dump file I/O) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='并行物理写(db file parallel write) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='lob对象物理读(lob reads) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='lob对象直接物理读(physical reads direct (lob)) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='磁盘至缓冲区物理读(physical reads cache) <块数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='RMAN备份恢复I/O(RMAN backup & recovery I/O) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='直接路径物理读(direct path read) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='直接路径物理写(direct path write) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='磁盘排序操作(sorts (disk)) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='onepass磁盘排序操作(workarea executions - onepass)' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='multipass磁盘排序操作(workarea executions - multipass)' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='锁请求等待次数(enqueue waits) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='事务锁（行锁争用）(enq: TX - row lock contention) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='并发锁等待(concurrency wait time) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='表锁争用(enq: TM - contention) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='事务锁（事务槽争用）(enq: TX - allocate ITL entry) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='死锁(enqueue deadlocks) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='高水位线等待(enq: HW - contention) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='事务锁（索引争用）(enq: TX - index contention) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='应用类等待时间(application wait time) <秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群类等待时间(cluster wait time) <秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='非空闲类等待时间(non-idle wait time) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='用户I/O类等待时间(user I/O wait time) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='调度类等待时间(scheduler wait time) <秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间current数据块接收数量(gc current blocks received) <块数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间current数据块发送数量(gc current blocks served) <块数/分钟>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间读等待次数(gc read waits) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间current数据块接收时间(gc current block receive time) <秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间current数据块发送时间(gc current block send time) <厘秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间读等待时间(gc read wait time) <厘秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间cr数据块接收数量(gc cr blocks received) <块数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间cr数据块发送数量(gc cr blocks served) <块数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间数据块读等待超时(gc read wait timeouts) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间cr数据块接收时间(gc cr block receive time) <秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间cr数据块发送时间(gc cr block send time) <厘秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间数据块读等待失败(gc read wait failures) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='集群间enqueue获取时间(global enqueue get time) <秒/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='CBC latch 等待次数(latch: cache buffers chains) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='free buffer 请求次数(free buffer requested) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='free buffer inspected(free buffer inspected) <块数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='buffer busy 等待次数(buffer busy waits) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='free buffer waits(free buffer waits) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='dirty buffers inspected(dirty buffers inspected) <块数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='CR块建立的数量(CR blocks created) <块数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='重做日志生成量(redo size) <KB/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='log file sync <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='latch: redo allocation <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo writes <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo synch writes <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='log file switch (checkpoint incomplete) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo write time <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo synch time <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='log file switch (archiving needed) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo synch time overhead count ( <2 msec) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo synch time overhead count ( <8 msec) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo synch time overhead count ( <32 msec) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo synch time overhead count ( <128 msec) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='redo synch time overhead count (>=128 msec) <分钟/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='UNDO表空间自动扩展次数(auto extends on undo tablespace) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='因UNDO段扩展或收缩而产生的等待(undo segment extension) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='为获取UNDO段事务槽而产生的等待(undo segment tx slot) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='table scans (short tables) <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='table scan blocks gotten <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='table fetch continued row <次数/秒>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='table scans (long tables) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='table scans (rowid ranges) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='table scans (direct read) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='leaf node splits <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='branch node splits <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='root node splits <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='并行select语句执行次数(queries parallelized) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='并行DML语句执行次数(DML statements parallelized) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='并行DDL语句执行次数(DDL statements parallelized) <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL*Net roundtrips to/from client <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL*Net roundtrips to/from dblink <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL*Net break/reset to dblink <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='bytes received via SQL*Net from client <MB/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='bytes received via SQL*Net from dblink <MB/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL*Net message from dblink <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='bytes sent via SQL*Net to client <MB/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='bytes sent via SQL*Net to dblink <MB/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL*Net message to dblink <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL*Net more data from client <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL*Net more data from dblink <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='SQL*Net break/reset to client <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='OS Page faults <页数/分钟>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='OS Swaps <页数/分钟>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='buffer cache 内存(buffer_cache) <G字节>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='最大PGA空间分配(maximum PGA allocated) <G字节>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='最大用户进程数量(max processes count) <个>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='shared pool 内存(shared pool) <G字节>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='PGA内存分配总量(total PGA allocated) <G字节>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='用户进程数量(process count) <个>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='large pool 内存(large pool) <兆字节>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='extra bytes read/written <兆字节/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc current block 2-way <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc cr block 2-way <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc current block congested <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc current block busy <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc cr block busy <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc cr block congested <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc cr multi block request <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc current multi block request <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='global cache busy <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='gc buffer busy <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='cursor: pin S <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='cursor: pin S wait on X <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='library cache lock <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='cursor: pin X <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='latch: shared pool <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='library cache pin <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='cursor: mutex S <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='latch free <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='library cache: mutex X <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='cursor: mutex X <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='latch: row cache objects <次数/小时>' --force >>$glogfile
$php add_graphs.php --graph-type=cg --graph-template-id=$gtid --host-id=$hostid --graph-title='library cache: mutex S <次数/小时>' --force >>$glogfile

graph_num=`cat $glogfile|wc -l`
graph_begin=`cat $glogfile|sed -n 1p|awk -F '(' '{print $3}'|awk -F ')' '{print $1}'`
graph_end=`cat $glogfile|sed -n '$p'|awk -F '(' '{print $3}'|awk -F ')' '{print $1}'`

echo "graph for history host done"
echo "-----------------------------------------"

#---------------------------------------------
#set path of datasource's rrds
echo "set path of datasource's rrds"

if [[ $graph_num != $graphs ]];then
	echo "graph has problem,graph numbers is [${graph_num}],we hope it is [${graphs}],exiting."
	exit;
fi;

mysql -uroot -p123456 $database <<EOF
set @user="$path_user";
set @node="$path_node";
set @begin="$graph_begin";
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/5_1.rrd'   ) where local_data_id =@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/5_2.rrd'   ) where local_data_id =1+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/5_3.rrd'   ) where local_data_id =2+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/5_4.rrd'   ) where local_data_id =3+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/5_5.rrd'   ) where local_data_id =4+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/5_6.rrd'   ) where local_data_id =5+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/5_7.rrd'   ) where local_data_id =6+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/5_8.rrd'   ) where local_data_id =7+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/6_1.rrd'   ) where local_data_id =8+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/6_2.rrd'   ) where local_data_id =9+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/6_3.rrd'   ) where local_data_id =10+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/6_4.rrd'   ) where local_data_id =11+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/7_1.rrd'   ) where local_data_id =12+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/7_2.rrd'   ) where local_data_id =13+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/7_3.rrd'   ) where local_data_id =14+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/7_4.rrd'   ) where local_data_id =15+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/7_5.rrd'   ) where local_data_id =16+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_1.rrd'   ) where local_data_id =17+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_2.rrd'   ) where local_data_id =18+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_3.rrd'   ) where local_data_id =19+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_4.rrd'   ) where local_data_id =20+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_5.rrd'   ) where local_data_id =21+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_6.rrd'   ) where local_data_id =22+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_7.rrd'   ) where local_data_id =23+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_8.rrd'   ) where local_data_id =24+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_9.rrd'   ) where local_data_id =25+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/8_10.rrd'  ) where local_data_id =26+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_1.rrd'   ) where local_data_id =27+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_2.rrd'   ) where local_data_id =28+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_3.rrd'   ) where local_data_id =29+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_4.rrd'   ) where local_data_id =30+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_5.rrd'   ) where local_data_id =31+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_6.rrd'   ) where local_data_id =32+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_7.rrd'   ) where local_data_id =33+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_8.rrd'   ) where local_data_id =34+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/9_9.rrd'   ) where local_data_id =35+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_1.rrd'  ) where local_data_id =36+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_2.rrd'  ) where local_data_id =37+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_3.rrd'  ) where local_data_id =38+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_4.rrd'  ) where local_data_id =39+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_5.rrd'  ) where local_data_id =40+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_6.rrd'  ) where local_data_id =41+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_7.rrd'  ) where local_data_id =42+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_8.rrd'  ) where local_data_id =43+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_9.rrd'  ) where local_data_id =44+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_10.rrd' ) where local_data_id =45+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/10_11.rrd' ) where local_data_id =46+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/11_1.rrd'  ) where local_data_id =47+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/11_2.rrd'  ) where local_data_id =48+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/11_3.rrd'  ) where local_data_id =49+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/12_1.rrd'  ) where local_data_id =50+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/12_2.rrd'  ) where local_data_id =51+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/12_3.rrd'  ) where local_data_id =52+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/12_4.rrd'  ) where local_data_id =53+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/12_5.rrd'  ) where local_data_id =54+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/12_6.rrd'  ) where local_data_id =55+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/12_7.rrd'  ) where local_data_id =56+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/12_8.rrd'  ) where local_data_id =57+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/13_1.rrd'  ) where local_data_id =58+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/13_2.rrd'  ) where local_data_id =59+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/13_3.rrd'  ) where local_data_id =60+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/13_4.rrd'  ) where local_data_id =61+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/13_5.rrd'  ) where local_data_id =62+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_1.rrd'  ) where local_data_id =63+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_2.rrd'  ) where local_data_id =64+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_3.rrd'  ) where local_data_id =65+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_4.rrd'  ) where local_data_id =66+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_5.rrd'  ) where local_data_id =67+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_6.rrd'  ) where local_data_id =68+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_7.rrd'  ) where local_data_id =69+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_8.rrd'  ) where local_data_id =70+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_9.rrd'  ) where local_data_id =71+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_10.rrd' ) where local_data_id =72+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_11.rrd' ) where local_data_id =73+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_12.rrd' ) where local_data_id =74+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/14_13.rrd' ) where local_data_id =75+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/15_1.rrd'  ) where local_data_id =76+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/15_2.rrd'  ) where local_data_id =77+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/15_3.rrd'  ) where local_data_id =78+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/15_4.rrd'  ) where local_data_id =79+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/15_5.rrd'  ) where local_data_id =80+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/15_6.rrd'  ) where local_data_id =81+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/15_7.rrd'  ) where local_data_id =82+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_1.rrd'  ) where local_data_id =83+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_2.rrd'  ) where local_data_id =84+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_3.rrd'  ) where local_data_id =85+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_4.rrd'  ) where local_data_id =86+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_5.rrd'  ) where local_data_id =87+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_6.rrd'  ) where local_data_id =88+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_7.rrd'  ) where local_data_id =89+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_8.rrd'  ) where local_data_id =90+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_9.rrd'  ) where local_data_id =91+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_10.rrd' ) where local_data_id =92+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_11.rrd' ) where local_data_id =93+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_12.rrd' ) where local_data_id =94+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_13.rrd' ) where local_data_id =95+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/16_14.rrd' ) where local_data_id =96+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/17_1.rrd'  ) where local_data_id =97+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/17_2.rrd'  ) where local_data_id =98+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/17_3.rrd'  ) where local_data_id =99+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/18_1.rrd'  ) where local_data_id =100+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/18_2.rrd'  ) where local_data_id =101+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/18_3.rrd'  ) where local_data_id =102+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/18_4.rrd'  ) where local_data_id =103+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/18_5.rrd'  ) where local_data_id =104+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/18_6.rrd'  ) where local_data_id =105+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/19_1.rrd'  ) where local_data_id =106+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/19_2.rrd'  ) where local_data_id =107+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/19_3.rrd'  ) where local_data_id =108+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/20_1.rrd'  ) where local_data_id =109+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/20_2.rrd'  ) where local_data_id =110+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/20_3.rrd'  ) where local_data_id =111+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_1.rrd'  ) where local_data_id =112+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_2.rrd'  ) where local_data_id =113+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_3.rrd'  ) where local_data_id =114+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_4.rrd'  ) where local_data_id =115+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_5.rrd'  ) where local_data_id =116+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_6.rrd'  ) where local_data_id =117+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_7.rrd'  ) where local_data_id =118+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_8.rrd'  ) where local_data_id =119+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_9.rrd'  ) where local_data_id =120+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_10.rrd' ) where local_data_id =121+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_11.rrd' ) where local_data_id =122+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/21_12.rrd' ) where local_data_id =123+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/22_1.rrd'  ) where local_data_id =124+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/22_2.rrd'  ) where local_data_id =125+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/23_1.rrd'  ) where local_data_id =126+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/23_2.rrd'  ) where local_data_id =127+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/23_3.rrd'  ) where local_data_id =128+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/23_4.rrd'  ) where local_data_id =129+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/23_5.rrd'  ) where local_data_id =130+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/23_6.rrd'  ) where local_data_id =131+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/23_7.rrd'  ) where local_data_id =132+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/23_8.rrd'  ) where local_data_id =133+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_1.rrd'  ) where local_data_id =134+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_2.rrd'  ) where local_data_id =135+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_3.rrd'  ) where local_data_id =136+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_4.rrd'  ) where local_data_id =137+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_5.rrd'  ) where local_data_id =138+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_6.rrd'  ) where local_data_id =139+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_7.rrd'  ) where local_data_id =140+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_8.rrd'  ) where local_data_id =141+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_9.rrd'  ) where local_data_id =142+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/24_10.rrd' ) where local_data_id =143+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_1.rrd'  ) where local_data_id =144+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_2.rrd'  ) where local_data_id =145+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_3.rrd'  ) where local_data_id =146+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_4.rrd'  ) where local_data_id =147+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_5.rrd'  ) where local_data_id =148+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_6.rrd'  ) where local_data_id =149+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_7.rrd'  ) where local_data_id =150+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_8.rrd'  ) where local_data_id =151+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_9.rrd'  ) where local_data_id =152+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_10.rrd' ) where local_data_id =153+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_11.rrd' ) where local_data_id =154+@begin  ;
update data_template_data set data_source_path = CONCAT('/cismon/rrds/', @user, '/', @node, '/25_12.rrd' ) where local_data_id =155+@begin  ;
commit;
EOF

echo "path of rrds has changed"
echo "-----------------------------------------"


#---------------------------------------------
#add graphs to tree
echo 'start add graphs to tree'

nodeid=`$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --name=${nodename}|awk -F '(' '{print $2}'|awk -F ')' '{print $1}'`

$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="数据库整体负载">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="数据库解析">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="CPU负载">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="I/O 物理读">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="I/O 物理写">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="I/O 非常规读写">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="排序瓶颈">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="锁争用">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="等待时间分类统计">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="集群性能监控">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="数据块缓冲区">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="重做日志性能">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="回滚表空间性能">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="表访问性能统计">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="索引对insert的性能影响">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="并行语句执行统计">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="网络性能">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="换页空间使用统计">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="数据库内存">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="集群等待事件">/dev/null
$php add_tree.php --sort-method=manual --type=node --node-type=header --tree-id=$treeid --parent-node=$nodeid --name="共享池锁争用">/dev/null

echo 'add class done,add graph'
graphids=`$php add_tree.php --list-graphs --host-id=$hostid|awk '{print $1}'|egrep ^[0-9]`
for i in $graphids;do
	$php add_tree.php --sort-method=manual --type=node --node-type=graph --tree-id=$treeid --graph-id="$i">>$tlogfile
done;

node_num=`cat $tlogfile|wc -l`
node_begin=`cat $tlogfile|sed -n 1p|awk -F '(' '{print $2}'|awk -F ')' '{print $1}'`
node_end=`cat $tlogfile|sed -n '$p'|awk -F '(' '{print $2}'|awk -F ')' '{print $1}'`

echo 'add to graph tree done'
echo "-----------------------------------------"

#---------------------------------------------
#order the tree

if [[ $node_num != $graphs ]];then
	echo "node has problem,node numbers is [${node_num}],we hope it is [${graphs}],exiting."
	exit;
fi;

mysql="mysql -uroot -p123456 $database"
sql="select order_key from graph_tree_items where id=${node_begin}-1;"
order_key=`echo "${sql}"|${mysql}|sed -n '$p'`
order_head=`echo ${order_key:0:3}`

echo "begin to order the tree"

mysql -uroot -p123456 $database <<FOE
set @begin="$node_begin";
set @order="$order_head";
update graph_tree_items set order_key=CONCAT(@order, '001001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=@begin;
update graph_tree_items set order_key=CONCAT(@order, '001002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=1+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '001003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=2+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '001004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=3+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '001005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=4+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '001006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=5+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '001007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=6+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '001008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=7+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '002001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=8+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '002002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=9+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '002003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=10+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '002004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=11+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '003001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=12+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '003002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=13+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '003003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=14+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '003004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=15+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '003005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=16+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=17+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=18+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=19+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=20+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=21+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=22+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=23+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=24+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004009000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=25+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '004010000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=26+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=27+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=28+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=29+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=30+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=31+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=32+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=33+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=34+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '005009000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=35+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=36+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=37+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=38+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=39+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=40+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=41+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=42+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=43+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006009000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=44+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006010000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=45+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '006011000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=46+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '007001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=47+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '007002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=48+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '007003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=49+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '008001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=50+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '008002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=51+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '008003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=52+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '008004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=53+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '008005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=54+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '008006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=55+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '008007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=56+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '008008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=57+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '009001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=58+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '009002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=59+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '009003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=60+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '009004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=61+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '009005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=62+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=63+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=64+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=65+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=66+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=67+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=68+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=69+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=70+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010009000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=71+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010010000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=72+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010011000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=73+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010012000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=74+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '010013000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=75+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '011001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=76+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '011002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=77+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '011003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=78+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '011004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=79+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '011005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=80+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '011006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=81+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '011007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=82+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=83+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=84+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=85+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=86+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=87+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=88+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=89+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=90+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012009000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=91+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012010000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=92+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012011000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=93+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012012000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=94+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012013000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=95+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '012014000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=96+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '013001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=97+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '013002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=98+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '013003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=99+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '014001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=100+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '014002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=101+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '014003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=102+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '014004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=103+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '014005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=104+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '014006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=105+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '015001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=106+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '015002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=107+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '015003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=108+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '016001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=109+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '016002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=110+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '016003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=111+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=112+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=113+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=114+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=115+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=116+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=117+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=118+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=119+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017009000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=120+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017010000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=121+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017011000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=122+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '017012000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=123+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '018001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=124+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '018002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=125+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '019001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=126+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '019002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=127+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '019003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=128+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '019004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=129+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '019005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=130+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '019006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=131+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '019007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=132+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '019008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=133+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=134+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=135+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=136+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=137+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=138+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=139+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=140+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=141+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020009000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=142+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '020010000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=143+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021001000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=144+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021002000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=145+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021003000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=146+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021004000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=147+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021005000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=148+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021006000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=149+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021007000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=150+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021008000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=151+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021009000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=152+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021010000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=153+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021011000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=154+@begin  ;
update graph_tree_items set order_key=CONCAT(@order, '021012000000000000000000000000000000000000000000000000000000000000000000000000000000000') where id=155+@begin  ;
commit;
FOE

echo "order the tree done"
echo "-----------------------------------------"
echo "congratulations,all done."
echo "###############################################"
