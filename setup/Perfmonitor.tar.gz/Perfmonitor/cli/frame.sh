php add_device.php --description='历史平台 10g节点1' --ip=H.10g.Node1 --template=10 --avail=none
php add_device.php --description='历史平台 10g节点2' --ip=H.10g.Node2 --template=10 --avail=none
php add_device.php --description='历史平台 10g节点3' --ip=H.10g.Node3 --template=10 --avail=none
php add_device.php --description='历史平台 10g节点4' --ip=H.10g.Node4 --template=10 --avail=none
php add_device.php --description='历史平台 10g节点5' --ip=H.10g.Node5 --template=10 --avail=none
php add_device.php --description='历史平台 10g节点6' --ip=H.10g.Node6 --template=10 --avail=none
php add_device.php --description='历史平台 10g节点7' --ip=H.10g.Node7 --template=10 --avail=none
php add_device.php --description='历史平台 10g节点8' --ip=H.10g.Node8 --template=10 --avail=none
php add_device.php --description='历史平台 10g节点9' --ip=H.10g.Node9 --template=10 --avail=none

php add_device.php --description='历史平台 11g节点1' --ip=H.11g.Node1 --template=10 --avail=none
php add_device.php --description='历史平台 11g节点2' --ip=H.11g.Node2 --template=10 --avail=none
php add_device.php --description='历史平台 11g节点3' --ip=H.11g.Node3 --template=10 --avail=none
php add_device.php --description='历史平台 11g节点4' --ip=H.11g.Node4 --template=10 --avail=none
php add_device.php --description='历史平台 11g节点5' --ip=H.11g.Node5 --template=10 --avail=none
php add_device.php --description='历史平台 11g节点6' --ip=H.11g.Node6 --template=10 --avail=none
php add_device.php --description='历史平台 11g节点7' --ip=H.11g.Node7 --template=10 --avail=none
php add_device.php --description='历史平台 11g节点8' --ip=H.11g.Node8 --template=10 --avail=none
php add_device.php --description='历史平台 11g节点9' --ip=H.11g.Node9 --template=10 --avail=none

php add_device.php --description='预警平台 10g节点1' --ip=M.10g.Node1 --template=9 --avail=none
php add_device.php --description='预警平台 10g节点2' --ip=M.10g.Node2 --template=9 --avail=none
php add_device.php --description='预警平台 10g节点3' --ip=M.10g.Node3 --template=9 --avail=none
php add_device.php --description='预警平台 10g节点4' --ip=M.10g.Node4 --template=9 --avail=none
php add_device.php --description='预警平台 10g节点5' --ip=M.10g.Node5 --template=9 --avail=none
php add_device.php --description='预警平台 10g节点6' --ip=M.10g.Node6 --template=9 --avail=none
php add_device.php --description='预警平台 10g节点7' --ip=M.10g.Node7 --template=9 --avail=none
php add_device.php --description='预警平台 10g节点8' --ip=M.10g.Node8 --template=9 --avail=none
php add_device.php --description='预警平台 10g节点9' --ip=M.10g.Node9 --template=9 --avail=none

php add_device.php --description='预警平台 11g节点1' --ip=M.11g.Node1 --template=9 --avail=none
php add_device.php --description='预警平台 11g节点2' --ip=M.11g.Node2 --template=9 --avail=none
php add_device.php --description='预警平台 11g节点3' --ip=M.11g.Node3 --template=9 --avail=none
php add_device.php --description='预警平台 11g节点4' --ip=M.11g.Node4 --template=9 --avail=none
php add_device.php --description='预警平台 11g节点5' --ip=M.11g.Node5 --template=9 --avail=none
php add_device.php --description='预警平台 11g节点6' --ip=M.11g.Node6 --template=9 --avail=none
php add_device.php --description='预警平台 11g节点7' --ip=M.11g.Node7 --template=9 --avail=none
php add_device.php --description='预警平台 11g节点8' --ip=M.11g.Node8 --template=9 --avail=none
php add_device.php --description='预警平台 11g节点9' --ip=M.11g.Node9 --template=9 --avail=none

php add_tree.php --type=tree --name='10g数据库历史数据分析平台' --sort-method=manual
php add_tree.php --type=tree --name='11g数据库历史数据分析平台' --sort-method=manual
php add_tree.php --type=tree --name='10g数据库性能预警平台' --sort-method=manual
php add_tree.php --type=tree --name='11g数据库性能预警平台' --sort-method=manual
