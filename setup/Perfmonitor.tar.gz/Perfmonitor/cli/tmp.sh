#!/bin/bash
./history10g.sh 1 2 
./history10g.sh 2 3 
./history10g.sh 3 4 
./history10g.sh 4 5 
./history10g.sh 5 6 
./history10g.sh 6 7 
./history10g.sh 7 8 
./history10g.sh 8 9 
./history10g.sh 9 10

./history11g.sh 1 11
./history11g.sh 2 12
./history11g.sh 3 13
./history11g.sh 4 14
./history11g.sh 5 15
./history11g.sh 6 16
./history11g.sh 7 17
./history11g.sh 8 18
./history11g.sh 9 19

./monitor10g.sh 1 20
./monitor10g.sh 2 21
./monitor10g.sh 3 22
./monitor10g.sh 4 23
./monitor10g.sh 5 24
./monitor10g.sh 6 25
./monitor10g.sh 7 26
./monitor10g.sh 8 27
./monitor10g.sh 9 28

./monitor11g.sh 1 29
./monitor11g.sh 2 30
./monitor11g.sh 3 31
./monitor11g.sh 4 32
./monitor11g.sh 5 33
./monitor11g.sh 6 34
./monitor11g.sh 7 35
./monitor11g.sh 8 36
./monitor11g.sh 9 37
