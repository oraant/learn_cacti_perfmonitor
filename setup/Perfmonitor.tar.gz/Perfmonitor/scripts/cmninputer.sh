#!/bin/bash
#string for test :"qdsailun pcdb_3.shell 3 1 2"

#pre difine
path=/cismon/datas
logfile="/cismon/log/cmninputer"
conf="/cismon/sbin/conf.sh"
log_mode=`$conf log_mode`
if [[ x$log_mode = x ]];then log_mode=1;fi

###############################################
#get parameters
user=$1
target=$2
rownum=$3
colnum=$4
device=$5

###############################################
#verify
laststamp=`cat ${path}/${user}/${target}.cur|sed -n 1p|awk '{print $1}'`
nowstamp=`date +%s`
diffstamp=`echo "$nowstamp-$laststamp"|bc`

type=`echo ${target}|awk -F "." '{print $2}'`
if [[ $type = shell ]];then
	if [[ $log_mode -ge 5 ]];then
	echo [`env LANG=en_US.UTF-8 date`]-[normal log] [$1 $2 $3 $4 $5] $'\t' [$nowstamp-$laststamp=`echo $nowstamp-$laststamp|bc`] >> ${logfile}.dbg
	fi

	if [[ $diffstamp -gt 90 ]];then
	echo [`env LANG=en_US.UTF-8 date`]-[expired data] [$1 $2 $3 $4 $5] $'\t' [$nowstamp-$laststamp=`echo $nowstamp-$laststamp|bc`] >> ${logfile}.err
        exit;
	fi
elif [[ $type = plsql ]];then
	if [[ $log_mode -ge 4 ]];then
	echo [`env LANG=en_US.UTF-8 date`]-[normal log] [$1 $2 $3 $4 $5] $'\t' [$nowstamp-$laststamp=`echo $nowstamp-$laststamp|bc`] >> ${logfile}.vbs
	fi

	if [[ $diffstamp -gt 900 ]];then
        echo [`env LANG=en_US.UTF-8 date`]-[expired data] [$1 $2 $3 $4 $5] $'\t' [$nowstamp-$laststamp=`echo $nowstamp-$laststamp|bc`] >> ${logfile}.err
        exit;
	fi
fi

###############################################
#get value from specified position
if [[ x$device = x ]];then
	adv=`cat ${path}/${user}/${target}.adv|sed -n ${rownum}p|awk '{print $'$colnum'}'`
	cur=`cat ${path}/${user}/${target}.cur|sed -n ${rownum}p|awk '{print $'$colnum'}'`
	war=`cat ${path}/${user}/${target}.war|sed -n ${rownum}p|awk '{print $'$colnum'}'`
else
	adv=`cat ${path}/${user}/${target}.adv|sed -n ${rownum}p|awk  '{print $'$colnum'}'|awk -F ',' '{print $'$device'}'|awk -F '=' '{print $2}'`
	cur=`cat ${path}/${user}/${target}.cur|sed -n ${rownum}p|awk  '{print $'$colnum'}'|awk -F ',' '{print $'$device'}'|awk -F '=' '{print $2}'`
	war=`cat ${path}/${user}/${target}.war|sed -n ${rownum}p|awk  '{print $'$colnum'}'|awk -F ',' '{print $'$device'}'|awk -F '=' '{print $2}'`
fi;

#out put
echo -n "adv:$adv cur:$cur war:$war"
